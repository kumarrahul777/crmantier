import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const loginFun = createAsyncThunk(
  "loginFun/auth",
  async (value, { rejectWithValue }) => {
    try {
      const res = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: value.username,
          password: value.password,
        }),
      });

      let data = await res.json();
      if (!data.token) {
        return rejectWithValue("An error occurred");
      } else {
        return data;
      }
    } catch (error) {
      return rejectWithValue(error.message || "An error occurred");
    }
  }
);

const initialState = {
  error: "",
  data: {},
};

export const logout = createSlice({
  name: "logout",
  initialState: initialState,
  reducers: {
    logoutUser: (state) => {
      state.data = {};
      state.error = "";
    },
  },
});
export const { logoutUser } = logout.actions;

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(loginFun.pending, (state, action) => {});
    builder.addCase(loginFun.fulfilled, (state, action) => {
      state.data = action.payload;
      state.error = "";
    });
    builder.addCase(loginFun.rejected, (state, action) => {
      console.log(action);
      state.error = action.payload;
      state.data = "";
    });
    builder.addCase(logoutUser, (state) => {
      state.data = {};
      state.error = "";
    });
  },
});

export default authSlice.reducer;
